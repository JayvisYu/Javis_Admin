import request from '@/utils/request'

export function Axios(params) {
    return request(params)
}
